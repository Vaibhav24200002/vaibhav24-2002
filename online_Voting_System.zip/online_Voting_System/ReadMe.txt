Technology Stack: HTML, CSS, Python (Django)
Frontend: HTML, CSS, Bootstrap
Backend: Python (Django)
Database: SQLite 

#SUPERUSER

admin_dashboard_path: http://127.0.0.1:8000/admin
ID: admin2
PASSWORD: 789

#PROJECT RUN COMMANDS

python manage.py makemigrations

python manage.py migrate

python manage.py  runserver
